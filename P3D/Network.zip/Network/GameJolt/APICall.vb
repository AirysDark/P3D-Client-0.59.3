﻿Imports System.Text
Imports System.IO
Imports System.Net
Imports System.Security.Cryptography

Namespace GameJolt

    Public Class APICall

        Public Structure JoltParameter
            Dim Name As String
            Dim Value As String
        End Structure

        Public Enum RequestMethod
            [GET]
            POST
        End Enum

        Private Class APIURL

            Dim Values As New Dictionary(Of String, String)
            Dim BaseURL As String = ""

            Public Sub New(ByVal baseURL As String)
                Me.BaseURL = baseURL

                ' Ensure a single leading slash for endpoint paths (e.g., "/users/auth")
                If Me.BaseURL.StartsWith("/") = False Then
                    Me.BaseURL = "/" & baseURL
                End If

                ' Do NOT force a trailing slash ? avoids "//" when concatenating
                ' (kept intentionally minimal per your request)
            End Sub

            Public Sub AddKeyValuePair(ByVal Key As String, ByVal Value As String)
                Me.Values.Add(Key, Value)
            End Sub

            Public ReadOnly Property GetURL() As String
                Get
                    ' Builds: http://127.0.0.1:8080 + api/game/v1_1 + /endpoint
                    Dim url As String = HOST & API.API_VERSION & Me.BaseURL

                    For i = 0 To Me.Values.Count - 1
                        Dim appendString As String = ""
                        If i = 0 Then
                            appendString &= "?"
                        Else
                            appendString &= "&"
                        End If
                        appendString &= Me.Values.Keys(i) & "="
                        appendString &= UrlEncoder.Encode(Me.Values.Values(i))

                        url &= appendString
                    Next

                    Return url
                End Get
            End Property

        End Class

        Public Delegate Sub DelegateCallSub(ByVal result As String)

        Public CallSub As DelegateCallSub

        Dim username As String
        Dim token As String

        Dim loggedIn As Boolean

        Const CONST_GAMEID As String = Classified.GameJolt_Game_ID
        Const CONST_GAMEKEY As String = Classified.GameJolt_Game_Key
        Public Const API_VERSION As String = "api/game/v1_1"
        Const HOST As String = "http://127.0.0.1:8080"

        Dim Exception As System.Exception = Nothing

        Public Event CallFails(ByVal ex As Exception)
        Public Event CallSucceeded(ByVal returnData As String)

        Private ReadOnly Property GameID() As String
            Get
                Return StringObfuscation.DeObfuscate(CONST_GAMEID)
            End Get
        End Property

        Private ReadOnly Property GameKey() As String
            Get
                Return StringObfuscation.DeObfuscate(CONST_GAMEKEY)
            End Get
        End Property

        Public Sub New(ByVal CallSub As DelegateCallSub)
            Me.CallSub = CallSub

            Me.username = API.username
            Me.token = API.token

            Me.loggedIn = API.LoggedIn
        End Sub

        Public Sub New()
            Me.username = API.username
            Me.token = API.token

            Me.loggedIn = API.LoggedIn
        End Sub

        Public Sub VerifyUser(ByVal newUsername As String, ByVal newToken As String)
            API.username = newUsername
            API.token = newToken
            username = newUsername
            token = newToken

            ' Use endpoint relative to API root; APIURL will prepend HOST & API_VERSION
            Dim url As New APIURL("/users/auth")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)

            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

#Region "Storage"

        Public Sub SetStorageData(ByVal key As String, ByVal data As String, ByVal useUsername As Boolean)
            If useUsername = True Then
                If loggedIn = False Then
                    Dim up As New Exception("User not logged in!")
                    Throw up
                Else
                    Dim url As New APIURL("/data-store/set/")
                    url.AddKeyValuePair("game_id", GameID)
                    url.AddKeyValuePair("username", username)
                    url.AddKeyValuePair("user_token", token)
                    url.AddKeyValuePair("key", key)

                    Initialize(url.GetURL(), RequestMethod.POST, data)
                End If
            Else
                Dim url As New APIURL("/data-store/set/")
                url.AddKeyValuePair("game_id", GameID)
                url.AddKeyValuePair("key", key)

                Initialize(url.GetURL(), RequestMethod.POST, data)
            End If
        End Sub

        Public Sub UpdateStorageData(ByVal key As String, ByVal value As String, ByVal operation As String, ByVal useUsername As Boolean)
            If useUsername = True Then
                If loggedIn = False Then
                    Dim up As New Exception("User not logged in!")
                    Throw up
                Else
                    Dim url As New APIURL("/data-store/update/")
                    url.AddKeyValuePair("game_id", GameID)
                    url.AddKeyValuePair("username", username)
                    url.AddKeyValuePair("user_token", token)
                    url.AddKeyValuePair("key", key)
                    url.AddKeyValuePair("operation", operation)
                    url.AddKeyValuePair("value", value)

                    Initialize(url.GetURL(), RequestMethod.GET)
                End If
            Else
                Dim url As New APIURL("/data-store/update/")
                url.AddKeyValuePair("game_id", GameID)
                url.AddKeyValuePair("key", key)
                url.AddKeyValuePair("operation", operation)
                url.AddKeyValuePair("value", value)

                Initialize(url.GetURL(), RequestMethod.GET)
            End If
        End Sub

        Public Sub SetStorageData(ByVal keys() As String, ByVal dataItems() As String, ByVal useUsernames() As Boolean)
            If keys.Length <> dataItems.Length Or keys.Length <> useUsernames.Length Then
                Dim ex As New Exception("The data arrays do not have the same lengths.")
                ex.Data.Add("Keys Length", keys.Length)
                ex.Data.Add("Data Length", dataItems.Length)
                ex.Data.Add("Username permission Length", useUsernames.Length)
                Throw ex
            End If

            Dim url As String = HOST & API.API_VERSION & "/batch/" & "?game_id=" & GameID & "&parallel=true"
            Dim postDataURL As String = ""

            For i = 0 To keys.Length - 1
                Dim key As String = keys(i)
                Dim data As String = dataItems(i)
                Dim useUsername As Boolean = useUsernames(i)

                If useUsername = True And loggedIn = False Then
                    Throw New Exception("User not logged in!")
                End If

                If useUsername = True Then
                    postDataURL &= "&requests[]=" & UrlEncoder.Encode(
                    GetHashedURL("/data-store/set/" & "?game_id=" & GameID &
                                 "&username=" & username & "&user_token=" & token &
                                 "&key=" & UrlEncoder.Encode(key) & "&data=" & UrlEncoder.Encode(data)))
                Else
                    postDataURL &= "&requests[]=" & UrlEncoder.Encode(
                    GetHashedURL("/data-store/set/" & "?game_id=" & GameID &
                                 "&key=" & UrlEncoder.Encode(key) & "&data=" & UrlEncoder.Encode(data)))
                End If
            Next

            Initialize(url, RequestMethod.POST, postDataURL)
        End Sub

        Public Sub SetStorageDataRestricted(ByVal key As String, ByVal data As String)
            Dim url As String = HOST & API.API_VERSION & "/data-store/set/" &
                            "?game_id=" & GameID & "&key=" & key &
                            "&restriction_username=" & API.username &
                            "&restriction_user_token=" & API.token

            Initialize(url, RequestMethod.POST, data)
        End Sub

        ' *** PATCHED: use /data-store/get/ (the shim implements this path) ***
        Public Sub GetStorageData(ByVal key As String, ByVal useUsername As Boolean)
            If useUsername = True Then
                If loggedIn = False Then
                    Throw New Exception("User not logged in!")
                Else
                    Dim url As New APIURL("/data-store/get/")
                    url.AddKeyValuePair("game_id", GameID)
                    url.AddKeyValuePair("username", username)
                    url.AddKeyValuePair("user_token", token)
                    url.AddKeyValuePair("key", key)

                    Initialize(url.GetURL(), RequestMethod.GET)
                End If
            Else
                Dim url As New APIURL("/data-store/get/")
                url.AddKeyValuePair("game_id", GameID)
                url.AddKeyValuePair("key", key)

                Initialize(url.GetURL(), RequestMethod.GET)
            End If
        End Sub

        ' *** PATCHED: batch reads must point to /data-store/get/ inside requests[] ***
        Public Sub GetStorageData(ByVal keys() As String, ByVal useUsername As Boolean)
            If useUsername = True Then
                If loggedIn = False Then
                    Throw New Exception("User not logged in!")
                Else
                    Dim url As String = HOST & API.API_VERSION & "/batch/"
                    Dim firstURL As Boolean = True

                    For Each key As String In keys
                        Dim keyURL As String = "?"
                        If firstURL = False Then keyURL = "&"

                        keyURL &= "requests[]=" & UrlEncoder.Encode(
                        GetHashedURL(HOST & API.API_VERSION & "/data-store/get/" &
                                     "?game_id=" & GameID & "&username=" & username &
                                     "&user_token=" & token & "&key=" & key))

                        url &= keyURL
                        firstURL = False
                    Next

                    url &= "&game_id=" & GameID
                    Initialize(url, RequestMethod.GET)
                End If
            Else
                Dim url As String = HOST & API.API_VERSION & "/batch/"
                Dim firstURL As Boolean = True

                For Each key As String In keys
                    Dim keyURL As String = "?"
                    If firstURL = False Then keyURL = "&"

                    keyURL &= "requests[]=" & UrlEncoder.Encode(
                    GetHashedURL(HOST & API.API_VERSION & "/data-store/get/" &
                                 "?game_id=" & GameID & "&key=" & key))

                    url &= keyURL
                    firstURL = False
                Next

                url &= "&game_id=" & GameID
                Initialize(url, RequestMethod.GET)
            End If
        End Sub

        ' NOTE: Your shim does not implement /users/ fetch; these will 404 unless you add it server-side.
        Public Sub FetchUserdata(ByVal username As String)
            Dim url As New APIURL("/users/")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

        Public Sub FetchUserdataByID(ByVal user_id As String)
            Dim url As New APIURL("/users/")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("user_id", user_id)
            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

        ' NOTE: Your shim also does not implement /data-store/get-keys/ or /data-store/remove/.
        ' Calling these will return 404 unless you extend the server.
        Public Sub GetKeys(ByVal useUsername As Boolean, ByVal pattern As String)
            If useUsername = True Then
                If loggedIn = False Then
                    Throw New Exception("User not logged in!")
                Else
                    Dim url As New APIURL("/data-store/get-keys/")
                    url.AddKeyValuePair("game_id", GameID)
                    url.AddKeyValuePair("username", username)
                    url.AddKeyValuePair("user_token", token)
                    url.AddKeyValuePair("pattern", pattern)
                    Initialize(url.GetURL(), RequestMethod.GET)
                End If
            Else
                Dim url As New APIURL("/data-store/get-keys/")
                url.AddKeyValuePair("game_id", GameID)
                url.AddKeyValuePair("pattern", pattern)
                Initialize(url.GetURL(), RequestMethod.GET)
            End If
        End Sub

        Public Sub RemoveKey(ByVal key As String, ByVal useUsername As Boolean)
            If useUsername = True Then
                If loggedIn = False Then
                    Throw New Exception("User Not logged in!")
                Else
                    Dim url As New APIURL("/data-store/remove/")
                    url.AddKeyValuePair("game_id", GameID)
                    url.AddKeyValuePair("username", username)
                    url.AddKeyValuePair("user_token", token)
                    url.AddKeyValuePair("key", key)
                    Initialize(url.GetURL(), RequestMethod.POST)
                End If
            Else
                Dim url As New APIURL("/data-store/remove/")
                url.AddKeyValuePair("game_id", GameID)
                url.AddKeyValuePair("key", key)
                Initialize(url.GetURL(), RequestMethod.POST)
            End If
        End Sub

#End Region

#Region "Sessions"

        ' Opens a session for the current user.
        Public Sub OpenSession()
            ' Server route: /api/game/v1_1/sessions/open
            Dim url As New APIURL("/sessions/open")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)

            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

        ' Legacy alias: just pings the session.
        Public Sub CheckSession()
            PingSession()
        End Sub

        ' Pings (keeps alive) the current session.
        Public Sub PingSession()
            ' Server route: /api/game/v1_1/sessions/ping
            Dim url As New APIURL("/sessions/ping")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)

            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

        ' Closes the session.
        Public Sub CloseSession()
            ' Server route: /api/game/v1_1/sessions/close
            Dim url As New APIURL("/sessions/close")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)

            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

#End Region

#Region "Trophy"

        Public Sub FetchAllTrophies()
            ' GET /api/game/v1_1/trophies
            Dim url As New APIURL("/trophies")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)

            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

        Public Sub FetchAllAchievedTrophies()
            ' GET /api/game/v1_1/trophies?achieved=true
            Dim url As New APIURL("/trophies")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)
            url.AddKeyValuePair("achieved", "true")

            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

        Public Sub FetchTrophy(ByVal trophy_id As Integer)
            ' GET /api/game/v1_1/trophies?trophy_id=#
            Dim url As New APIURL("/trophies")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)
            url.AddKeyValuePair("trophy_id", trophy_id.ToString())

            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

        Public Sub TrophyAchieved(ByVal trophy_id As Integer)
            ' POST /api/game/v1_1/trophies/add-achieved
            Dim url As New APIURL("/trophies/add-achieved")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)
            url.AddKeyValuePair("trophy_id", trophy_id.ToString())

            Initialize(url.GetURL(), RequestMethod.POST)
        End Sub

        Public Sub RemoveTrophyAchieved(ByVal trophy_id As Integer)
            ' POST /api/game/v1_1/trophies/remove-achieved
            Dim url As New APIURL("/trophies/remove-achieved")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)
            url.AddKeyValuePair("trophy_id", trophy_id.ToString())

            Initialize(url.GetURL(), RequestMethod.POST)
        End Sub

#End Region

#Region "ScoreTable"

        Public Sub FetchTable(ByVal score_count As Integer, ByVal table_id As String)
            ' GET /api/game/v1_1/scores?limit=#&table_id=...
            Dim url As New APIURL("/scores")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("limit", score_count.ToString())
            url.AddKeyValuePair("table_id", table_id)

            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

        Public Sub FetchUserRank(ByVal table_id As String, ByVal sort As Integer)
            ' GET /api/game/v1_1/scores/get-rank?sort=#&table_id=...
            Dim url As New APIURL("/scores/get-rank")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("sort", sort.ToString())
            url.AddKeyValuePair("table_id", table_id)

            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

        Public Sub AddScore(ByVal score As String, ByVal sort As Integer, ByVal table_id As String)
            ' POST /api/game/v1_1/scores/add
            Dim url As New APIURL("/scores/add")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)
            url.AddKeyValuePair("score", score)
            url.AddKeyValuePair("sort", sort.ToString())
            url.AddKeyValuePair("table_id", table_id)

            Initialize(url.GetURL(), RequestMethod.POST)
        End Sub

#End Region

#Region "Friends"

        Public Sub FetchFriendList(ByVal user_id As String)
            ' GET /api/game/v1_1/friends?game_id=...&username=...&user_token=...
            Dim url As New APIURL("/friends")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)
            url.AddKeyValuePair("user_id", user_id)

            Initialize(url.GetURL(), RequestMethod.GET)
        End Sub

        Public Sub AddFriend(ByVal friend_username As String)
            Dim url As New APIURL("/friends/add")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)
            url.AddKeyValuePair("friend_username", friend_username)

            Initialize(url.GetURL(), RequestMethod.POST)
        End Sub

        Public Sub RemoveFriend(ByVal friend_username As String)
            Dim url As New APIURL("/friends/remove")
            url.AddKeyValuePair("game_id", GameID)
            url.AddKeyValuePair("username", username)
            url.AddKeyValuePair("user_token", token)
            url.AddKeyValuePair("friend_username", friend_username)

            Initialize(url.GetURL(), RequestMethod.POST)
        End Sub

#End Region

        ' --- fields ---
        Private url As String = ""
        Private PostData As String = ""

        Private Function GetHashedURL(ByVal url As String) As String
            Dim m As MD5 = MD5.Create()
            Dim data() As Byte = m.ComputeHash(Encoding.UTF8.GetBytes(url & GameKey))

            Dim sBuild As New StringBuilder()
            For i = 0 To data.Length - 1
                sBuild.Append(data(i).ToString("x2"))
            Next

            Dim newurl As String = url & "&signature=" & sBuild.ToString()
            Return newurl
        End Function

        Private Sub Initialize(ByVal url As String, ByVal method As RequestMethod, Optional ByVal PostData As String = "")
            Exception = Nothing

            ' The client expects keypair-style responses.
            Dim newurl As String = GetHashedURL(url & "&format=keypair")

            Debug.Print(newurl) 'Intentional for troubleshooting

            If method = RequestMethod.POST Then
                Me.url = newurl
                Me.PostData = PostData

                Dim t As New Threading.Thread(AddressOf POSTRequst) ' keep name to match existing code
                t.IsBackground = True
                t.Start()
            Else
                Try
                    Dim request As HttpWebRequest = CType(WebRequest.Create(newurl), HttpWebRequest)
                    request.Method = method.ToString()
                    request.KeepAlive = False
                    request.ServicePoint.Expect100Continue = False

                    request.BeginGetResponse(AddressOf EndResult, request)
                Catch ex As Exception
                    API.APICallCount -= 1
                    RaiseEvent CallFails(ex)
                End Try
            End If

            API.APICallCount += 1
        End Sub

        Private Sub POSTRequst()
            Dim gotData As String = ""
            Dim gotDataSuccess As Boolean = False

            Try
                Dim request As HttpWebRequest = CType(WebRequest.Create(url), HttpWebRequest)
                request.Method = "POST"
                request.KeepAlive = False
                request.ServicePoint.Expect100Continue = False

                ' Some POST endpoints (like trophies/add-achieved) don't send a body.
                Dim bodyBytes() As Byte = Nothing
                If String.IsNullOrEmpty(PostData) Then
                    bodyBytes = Array.Empty(Of Byte)()
                Else
                    ' Server expects classic x-www-form-urlencoded with a "data=" field for /data-store/set
                    ' (Call sites already pass the raw value; we URL-encode here.)
                    Dim body As String = "data=" & UrlEncoder.Encode(PostData)
                    bodyBytes = Encoding.UTF8.GetBytes(body)
                    request.ContentType = "application/x-www-form-urlencoded"
                End If

                request.ContentLength = bodyBytes.Length

                If bodyBytes.Length > 0 Then
                    Using reqStream = request.GetRequestStream()
                        reqStream.Write(bodyBytes, 0, bodyBytes.Length)
                    End Using
                End If

                Using response As HttpWebResponse = CType(request.GetResponse(), HttpWebResponse)
                    Using rs = response.GetResponseStream()
                        Using sr As New StreamReader(rs, Encoding.UTF8)
                            gotData = sr.ReadToEnd()
                        End Using
                    End Using
                End Using

                gotDataSuccess = True
            Catch ex As WebException
                ' If the server returned an error payload, surface it
                Try
                    Using resp = CType(ex.Response, HttpWebResponse)
                        If resp IsNot Nothing Then
                            Using rs = resp.GetResponseStream()
                                Using sr As New StreamReader(rs, Encoding.UTF8)
                                    Dim err = sr.ReadToEnd()
                                    Dim statusText As String = If(resp Is Nothing, "?", CInt(resp.StatusCode).ToString())
                                    RaiseEvent CallFails(New Exception($"HTTP {statusText}: {err}"))
                                End Using
                            End Using
                        Else
                            RaiseEvent CallFails(ex)
                        End If
                    End Using
                Catch
                    RaiseEvent CallFails(ex)
                End Try
            Catch ex As Exception
                RaiseEvent CallFails(ex)
            Finally
                API.APICallCount -= 1
            End Try

            ' Fire success callbacks after counters are updated.
            If gotDataSuccess Then
                If CallSub IsNot Nothing Then
                    CallSub(gotData)
                    RaiseEvent CallSucceeded(gotData)
                End If
            End If
        End Sub

        Private Sub EndResult(ByVal result As IAsyncResult)
            Dim data As String = ""

            Try
                If result.IsCompleted Then
                    Dim request As HttpWebRequest = CType(result.AsyncState, HttpWebRequest)
                    Using response As HttpWebResponse = CType(request.EndGetResponse(result), HttpWebResponse)
                        Using rs = response.GetResponseStream()
                            Using sr As New StreamReader(rs, Encoding.UTF8)
                                data = sr.ReadToEnd()
                            End Using
                        End Using
                    End Using
                End If
            Catch ex As WebException
                Try
                    Using resp = CType(ex.Response, HttpWebResponse)
                        If resp IsNot Nothing Then
                            Using rs = resp.GetResponseStream()
                                Using sr As New StreamReader(rs, Encoding.UTF8)
                                    Dim err = sr.ReadToEnd()
                                    Dim statusText As String = If(resp Is Nothing, "?", CInt(resp.StatusCode).ToString())
                                    RaiseEvent CallFails(New Exception($"HTTP {statusText}: {err}"))
                                End Using
                            End Using
                        Else
                            RaiseEvent CallFails(ex)
                        End If
                    End Using
                Catch
                    RaiseEvent CallFails(ex)
                End Try
            Catch ex As Exception
                RaiseEvent CallFails(ex)
            Finally
                API.APICallCount -= 1
            End Try

            If data <> "" AndAlso CallSub IsNot Nothing Then
                RaiseEvent CallSucceeded(data)
                CallSub(data)
            End If
        End Sub
    End Class

End Namespace